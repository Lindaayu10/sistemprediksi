|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Documents](Documents) || [Credits](Credits) || **+Contact+** ||

# Project contact details
## Contact project manager / Contribute
Contacting the project manager can be done using this e-mail address: [mailto:maarten@phpexcel.net](mailto:maarten@phpexcel.net)

## Project website
Some useful internet addresses:
* Project homepage [http://www.codeplex.com/PHPExcel](http://www.codeplex.com/PHPExcel)
* Project releases [http://www.codeplex.com/PHPExcel/Release/ProjectReleases.aspx](http://www.codeplex.com/PHPExcel/Release/ProjectReleases.aspx)
* Discussion forum [http://www.codeplex.com/PHPExcel/Thread/List.aspx](http://www.codeplex.com/PHPExcel/Thread/List.aspx)
* Issue tracker [http://www.codeplex.com/PHPExcel/WorkItem/List.aspx](http://www.codeplex.com/PHPExcel/WorkItem/List.aspx)

## Feature requests
Please check the following URL when posting feature requests:
[http://www.codeplex.com/PHPExcel/Thread/View.aspx?ThreadId=7362](http://www.codeplex.com/PHPExcel/Thread/View.aspx?ThreadId=7362).

## Issue tracker
When you found an issue regarding this project, please report it using this URL: [http://www.codeplex.com/PHPExcel/WorkItem/List.aspx](http://www.codeplex.com/PHPExcel/WorkItem/List.aspx).