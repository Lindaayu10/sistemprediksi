|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Documents](Documents) || [Credits](Credits) || [Contact](Contact) ||

# Donation acknowledgements

## Donations
[Donate via PayPal](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=paypal%40phpexcel%2enet&item_name=PHPExcel%20%2d%20Donation&amount=&no_shipping=1&return=http%3a%2f%2fwww%2ephpexcel%2enet&cancel_return=http%3a%2f%2fwww%2ephpexcel%2enet&cn=Your%20comments&tax=0&currency_code=EUR&lc=BE&bn=PP%2dDonationsBF&charset=UTF%2d8).

## Acknowledgements
We would like to thank the following people / companies for their donations:
* [SCHÖTEX IT-Solutions GmbH](http://www.schoetex.de)
* [Linear Design Group](http://www.lineardesign.net)
* [2FIT Webproducten](http://www.2fit.be/)
* [Pilot Simple Software](http://www.pilot.com.hk)
* [The Flagship](http://www.theflagship.co.uk)
* Jill Elaine
* Kim Ausloos
* [Manaz GmbH](http://www.manaz.de)
* [Webilicious](http://webilicious.com.au/)
* [DeDupeYourData.com](http://www.dedupeyourdata.com)
