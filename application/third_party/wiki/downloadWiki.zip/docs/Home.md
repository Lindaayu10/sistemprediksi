|| **+Home+** || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Documents](Documents) || [Credits](Credits) || [Contact](Contact) ||

# We moved to [https://github.com/PHPOffice/PHPExcel](https://github.com/PHPOffice/PHPExcel) nearly 5 years ago
## The site here on codeplex is no longer current!
## Please stop using it!!!

# PHPExcel - OpenXML - Read, Write and Create Excel documents in PHP - Spreadsheet engine
PHPExcel (OLD DEAD REPOSITORY) - visit PHPOffice/PHPExcel on github instead
Checkout the [Features](Features) this class set provides, such as setting spreadsheet meta data (author, title, description, ...), multiple worksheets, different fonts and font styles, cell borders, fills, gradients, adding images to your spreadsheet, calculating formulas, converting between file types and much, much more!

Want to bookmark this page? Please use [http://www.phpexcel.net](http://www.phpexcel.net) as the URL.

## Want to contribute?
Please remember that we have been using github as our source repository for over two years now.... source code has not been maintained here on Codeplex in all that time.  
If you want to contribute, you can fork the develop branch from github. We do accept Pull Requests.

Please refer the [Contribute](Contribute) page.

## Downloads
All code is now maintained on github
Last release here on codeplex: [release:119187](release_119187) is not the latest official release

## News

#### **2015-08-10** Friendly Reminder!
**We moved to [https://github.com/PHPOffice/PHPExcel](https://github.com/PHPOffice/PHPExcel) over 3 years ago**
The site here on codeplex is no longer current

#### **2014-03-02** Release 1.8.0 out now!
Despite earlier news to the contrary, the 1.x branch of PHPExcel is still not end of line, and the branch will continue to be maintained alongside the development of the version 2.x branch for the time being.

Current release [release:119187](release_119187). check the changelog for details!


#### **2013-06-02** Looking forward to PHPExcel 2.0.0!
Please note that PHPExcel 1.7.9 will be the last release of PHPExcel in the 1.x branch.

The next release will be 2.0.0 and it will require a minimum PHP version of 5.3. This will allow us to take advantage of language features that are only available in 5.3, including namespaces, closures, late static binding and guaranteed access to SPL. These features will in turn allow us to make significant improvements in performance and memory usage, as well as making the code cleaner and easier to maintain.
In addition to this core rewrite, planned changes to the PHPExcel functionality will include switching the XML-based readers to use XMLReader rather than SimpleXML; and a complete rewrite of the Calculation Engine to improve performance and provide support for array functions, for row and column references, for R1C1 references, better locale handling (particularly for date functions), and to make it more easily extensible.

Where possible, we will try to make the API consistent with the current API, but these changes mean that scripts using PHPExcel 2.x will not always be fully backward compatible with scripts using PHPExcel 1.x, but we hope that the improvements will be worth it.

#### **2013-06-02** Release 1.7.9 out now!
Current release [release:107442](release_107442). check the changelog for details!


#### **2013-05-22** Documentation now online!
In honour of World Goth Day, most of the PHPExcel documentation is now online at  [https://github.com/PHPOffice/PHPExcel/wiki/User%20Documentation](https://github.com/PHPOffice/PHPExcel/wiki/User%20Documentation)  
Looking for volunteers to help proofread and sanity test all the code snippets and recipes to be certain that they all work and are easily understandable.

#### **2013-05-22** We are on Github!
Please remember that we have been using github as our source repository for nearly a year now.... source code has not been maintained here on Codeplex in all that time.  
If you want to contribute, you can fork it. We do accept Pull Requests.

#### **2012-12-18** Free German language e-book now available!
For those who read German, Ralf Hohoff has published a free e-book on "Automated document generation with PHPExcel, PHPWord and PHPPowerPoint", available from [http://ebookstr.e-bookshelf.de/php-for-office-403106.html](http://ebookstr.e-bookshelf.de/php-for-office-403106.html).

#### **2012-10-12** Release 1.7.8 out now!
Current release [release:96183](release_96183). check the changelog for details!

#### **2012-06-19** PHPExcel Moves to github!
The source repository for PHPExcel, together with its sister projects PHPWord and PHPPowerPoint under the auspices of PHPOffice. The repository can be found at [https://github.com/PHPOffice/PHPExcel](https://github.com/PHPOffice/PHPExcel), and the latest working development code is in the develop branch.
This is the first part of series of changes in our development process which we believe will make it easier for us to do more frequent releases of better quality code. The next step will be CI integration for running automated unit testing against PHP 5.2, 5.3 and 5.4 using TravisCI.
We shall be maintaining the CodePlex SVN Source repository in parallel for a time, but the github repository should be considered the definitive source.

#### **2012-05-19** Release 1.7.7 out now!
Current release [release:88098](release_88098). check the changelog for details!

#### **2012-05-06** Ruby/PHP Bridge: accessing PHPExcel from Ruby!
Kasper Johansen has written a Ruby PHP Bridge, allowing the use of PHPExcel from within Ruby.
More details available from the code repository is at [https://github.com/kaspernj/php_process](https://github.com/kaspernj/php_process) for any Ruby coders wanting to try it. You can find a working example using PHPExcel to generate an Excel file at [https://github.com/kaspernj/php_process/blob/master/examples/example_phpexcel.rb](https://github.com/kaspernj/php_process/blob/master/examples/example_phpexcel.rb).

#### **2012-01-02** [discussion:284725](discussion_284725) 

#### **2011-02-28** Release 1.7.6 out now!
Current release [release:45412](release_45412). check the changelog for details!

#### **2010-12-10** Release 1.7.5 out now!
Current release [release:26479](release_26479). check the changelog for details!

#### **2010-10-22** PHPExcel ported to Python!
Eric Gazoni has just released the first version of a port of PHPExcel to Python... openpyxl/
More details available from his blog at [http://ericgazoni.wordpress.com/2010/04/10/openpyxl-python-xlsx/](http://ericgazoni.wordpress.com/2010/04/10/openpyxl-python-xlsx/). and the code repository is at [http://bitbucket.org/ericgazoni/openpyxl/](http://bitbucket.org/ericgazoni/openpyxl/) for any Python coders wanting to try it

#### **2010-08-26** Release 1.7.4 out now!
Current release [release:26478](release_26478). check the changelog for details!

We now also have a full PEAR channel! Here's how to use it:

New installation:
_pear channel-discover pear.pearplex.net_
_pear install pearplex/PHPExcel_

Or if you've already installed PHPExcel before:
_pear upgrade pearplex/PHPExcel_

The official page can be found at [http://pearplex.net](http://pearplex.net).

#### **2010-05-31** Release 1.7.3c out now!
Current release [release:46345](release_46345), check the changelog for details!

#### **2010-05-31** Release 1.7.3b out now!
Current release [release:46240](release_46240), check the changelog for details!

#### **2010-05-17** Release 1.7.3 out now!
Current release [release:26477](release_26477), check the changelog for details!

#### **2010-01-11** Release 1.7.2 out now!
Current release [release:10719](release_10719), check the changelog for details!

#### **2009-11-02** Release 1.7.1 out now!
Current release [release:10718](release_10718), check the changelog for details!

#### **2009-08-10** Release 1.7.0 out now!
Current release [release:10717](release_10717), check the changelog for details!

#### **2009-05-07** New PHPExcel tutorial available
There is a new PHPExcel tutorial available over at [OpenXmlDeveloper.org](http://openxmldeveloper.org/articles/4606.aspx). If you are just starting working with PHPExcel, this is a good read!

#### **2009-04-27** Create PowerPoint 2007 files from PHP
PHPExcel has a new sister project: [PHPPowerPoint](http://www.phppowerpoint.net). Just like with PHPExcel, PHPPowerPoint can be used to generate PPTX files from a PHP application. This can be done by creating an in-memory presentation that consists of slides and different shapes, which can then be written to disk using a writer (of which there’s currently only one for PowerPoint 2007).

* **[News archive](News-archive)**

## Team members
Check the [Credits](Credits) for a complete list of team members.