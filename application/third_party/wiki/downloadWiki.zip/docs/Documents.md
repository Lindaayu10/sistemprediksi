|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || **+Documents+** || [Credits](Credits) || [Contact](Contact) ||

# Documents
## PHPExcel documents
* Project guidelines on [Contribute](Contribute) page

## File format documentation
### OpenXML / SpreadsheetML
* [http://www.ecma-international.org/news/TC45_current_work/TC45_available_docs.htm](http://www.ecma-international.org/news/TC45_current_work/TC45_available_docs.htm)
### OpenXML Explained e-book
* [http://openxmldeveloper.org/articles/1970.aspx](http://openxmldeveloper.org/articles/1970.aspx)
### GoogleSpreadsheets
* [http://code.google.com/apis/spreadsheets/gdata.html](http://code.google.com/apis/spreadsheets/gdata.html)

## Tools
* Microsoft Office Compatibility Pack for Word, Excel, and PowerPoint 2007 File Formats [http://www.microsoft.com/downloads/details.aspx?familyid=941b3470-3ae9-4aee-8f43-c6bb74cd1466&displaylang=en](http://www.microsoft.com/downloads/details.aspx?familyid=941b3470-3ae9-4aee-8f43-c6bb74cd1466&displaylang=en)
* OpenXML Package Explorer [http://www.codeplex.com/PackageExplorer/](http://www.codeplex.com/PackageExplorer/)

## Links
* English PHPExcel tutorial [http://openxmldeveloper.org/articles/4606.aspx](http://openxmldeveloper.org/articles/4606.aspx)
* French PHPExcel tutorial [http://g-ernaelsten.developpez.com/tutoriels/excel2007/PHPExcel.pdf](http___g-ernaelsten.developpez.com_tutoriels_excel2007_PHPExcel.pdf) (updated)
* Web-junior has posted a number of entries in Russian on his blog about how to use PHPExcel [http://www.web-junior.net/sozdanie-excel-fajjlov-s-pomoshhyu-phpexcel/](http://www.web-junior.net/sozdanie-excel-fajjlov-s-pomoshhyu-phpexcel/)
* A Japanese-language introduction to PHPExcel [http://journal.mycom.co.jp/articles/2009/03/06/phpexcel/index.html](http://journal.mycom.co.jp/articles/2009/03/06/phpexcel/index.html)

## PHP Libraries
### OpenXML
* [http://www.codeplex.com/PHPExcel](http://www.codeplex.com/PHPExcel) ;-)
### ODF
* [http://www.fallengods.com/blog/php-opendocument-library/](http://www.fallengods.com/blog/php-opendocument-library/)
### Excel (BIFF)
* [http://sourceforge.net/projects/phpexcelreader](http://sourceforge.net/projects/phpexcelreader)
* [http://pear.php.net/package/Spreadsheet_Excel_Writer/](http://pear.php.net/package/Spreadsheet_Excel_Writer/)

## Links
### OpenXML
* [http://grandfather.developpez.com/articles/openxml/php/lecture/](http://grandfather.developpez.com/articles/openxml/php/lecture/)