|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Documents](Documents) || [Credits](Credits) || [Contact](Contact) ||

# News archive

#### **2009-04-22** Release 1.6.7 out now!
Current release [release:10716](release_10716), check the changelog for details!

#### **2009-03-02** Release 1.6.6 out now!
Current release [release:10715](release_10715), check the changelog for details!

#### **2009-02-03** Blog post: Saving a PHPExcel spreadsheet to Google Documents
As you may know, PHPExcel is built using an extensible model, supporting different input and output formats. The PHPExcel core class library features a spreadsheet engine, which is supported by IReader and IWriter instances used for reading and writing a spreadsheet to/from a file. Currently, PHPExcel supports writers for Excel2007, Excel5 (Excel 97+), CSV, HTML and PDF. Wouldnt it be nice if we could use PHPExcel to store a spreadsheet on Google Documents? 

Read the entire blog post on [Maarten Balliauw's blog](http://blog.maartenballiauw.be/post/2009/02/03/Saving-a-PHPExcel-spreadsheet-to-Google-Documents.aspx).

#### **2009-01-05** Release 1.6.5 out now!
Current release [release:10714](release_10714), check the changelog for details!

#### **2008-12-01** PHPExcel featured in php|architect / November 2008
Including graph support! Check my blog at [http://blog.maartenballiauw.be/post/2008/12/01/PHPExcel-featured-in-php7carchitect-November-2008.aspx](http://blog.maartenballiauw.be/post/2008/12/01/PHPExcel-featured-in-php7carchitect-November-2008.aspx)

#### **2008-10-27** Release 1.6.4 out now!
Current release [release:10713](release_10713), check the changelog for details!

#### **2008-03-27** Use Excel business logic in PHP
In many companies, business logic resides in Excel. This business logic is sometimes created by business analysts and sometimes by business users who want to automate parts of their everyday job using Excel. This same Excel-based business logic is often copied into an application (i.e. a website) and is maintained on 2 places: if the Excel logic changes, the application should also be modified.

On his blog, [Maarten Balliauw](http://blog.maartenballiauw.be) tells you how you can [use PHPExcel to take advantage of the Excel-based business logic](http://blog.maartenballiauw.be/post/2008/03/Reuse-Excel-business-logic-with-PHPExcel.aspx) without having to worry about duplicate business logic.

#### **2008-08-25** Release 1.6.3 out now!
Current release [release:10712](release_10712), check the changelog for details!

#### **2008-06-23** Release 1.6.2 out now!
Current release [release:9402](release_9402), check the changelog for details!

#### **2008-04-28** Release 1.6.1 out now!
Current release [release:9401](release_9401), check the changelog for details!

#### **2008-02-14** Release 1.6.0 out now!
Current release [release:5969](release_5969), checkout the changelog for details!

#### **2007-12-23** Release 1.5.5 out now!
Current release [release:5968](release_5968), checkout the changelog for details!

#### **2007-11-19** Code snapshots available!
Can't wait untill the next release is finished? Want a (possibly unstable) code snapshot? Check the "Source Code" tab or [http://www.codeplex.com/PHPExcel/SourceControl/ListDownloadableCommits.aspx](http://www.codeplex.com/PHPExcel/SourceControl/ListDownloadableCommits.aspx).

#### **2007-10-23** Release 1.5.0 out now!
Current release [release:5967](release_5967), checkout the changelog for details!

#### **2007-08-23** Release 1.4.5 out now!
Current release [release:5135](release_5135), checkout the changelog for details!

#### **2007-07-23** Typo3 features PHPExcel module
Typo3, one of the most feature-rich and free Content Management Frameworks built with PHP, features a PHPExcel module: [http://typo3.org/extensions/repository/view/phpexcel_library/1.0.1/](http://typo3.org/extensions/repository/view/phpexcel_library/1.0.1/).
People working with Typo3 can now download this module and start creating PHPExcel spreadsheets right away!

#### **2007-07-23** Release 1.4.0 out now!
Current release [release:4661](release_4661), checkout the changelog for details!

#### **2007-06-27** Release 1.3.5 out now!
Current release [release:4415](release_4415), checkout the changelog for details!

#### **2007-06-18** First draft of documentation finished
A first draft of documentation has been released with [release:3560](release_3560).

#### **2007-06-04** Release 1.3.0 out now!
Current release [release:3560](release_3560), checkout the changelog for details!

#### **2007-05-17** New project members!
We wish to welcome Morgan Davis and Sorin Stoiana as developer to the PHPExcel project.

#### **2007-05-03** PEAR package also available
A package for use with the PEAR installer is now also available in the release [release:2585](release_2585). These packages will be provided with every release from now on. Please note that the PEAR package does not contain example code or documentation!

#### **2007-04-26** php|architect magazine features PHPExcel!
Check [http://www.phparch.com](http://www.phparch.com), the April issue contains an article on PHP and SpreadsheetML.

#### **2007-04-23** Release 1.2.0 out now!
Current release [release:2585](release_2585), checkout the changelog for details!
This release is the first release licensed as LGPL instead op GPL. This allows proprietary software developers to also include PHPExcel in their code.

#### **2007-04-10** News on the upcoming release
The upcoming 1.2.0 release will support lots of new [Features](Features), check the issue tracker for a full list of completed work items on this release.

#### **2007-03-26** New release!
Current release [release:2678](release_2678), which fixes some small non-critical bugs.

#### **2007-03-22** New release!
Current release [release:2177](release_2177), checkout the changelog for details!
Version 1.0.0 has been downloaded 1250 times, a nice user base. **If you created a cool application using PHPExcel, and want to share a testimonial, please [Contact](Contact) me.**

#### **2007-03-08** Date for next release
Version 1.1.0, which contains new features and bugfixes, will be released by 2007-03-22

#### **2007-02-22** New release!
Current release [release:1980](release_1980), checkout the changelog for details!

#### **2007-02-14** We have a new team member!
We have a new team member, Jakub Vrana. Jakub is working on a Excel2007 reader... Stay tuned! Welcome Jakub!