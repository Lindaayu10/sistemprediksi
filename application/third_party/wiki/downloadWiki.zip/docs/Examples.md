|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || **+Examples+** || [FAQ](FAQ) || [Contribute](Contribute) || [Documents](Documents) || [Credits](Credits) || [Contact](Contact) ||

# Examples
Examples can be found in the test package in the latest release.

## File examples
The following examples are included, each representing another feature of PHPExcel:
* [01simple.xlsx](Examples_01simple.xlsx)
* [02types.xlsx](Examples_02types.xlsx)
* [03formulas.xlsx](Examples_03formulas.xlsx)
* [04printing.xlsx](Examples_04printing.xlsx)
* [05featuredemo.xlsx](Examples_05featuredemo.xlsx)
* [06largescale.xlsx](Examples_06largescale.xlsx)
* [07reader.xlsx](Examples_07reader.xlsx)
* [08conditionalformatting.xlsx](Examples_08conditionalformatting.xlsx)
* [09pagebreaks.xlsx](Examples_09pagebreaks.xlsx)
* [10autofilter.xlsx](Examples_10autofilter.xlsx)
* [11documentsecurity.xlsx](Examples_11documentsecurity.xlsx)
* [12serializedfileformat.xlsx](Examples_12serializedfileformat.xlsx)
* [14excel5.xls](Examples_14excel5.xls)
* [15datavalidation.xlsx](Examples_15datavalidation.xlsx)

## Hello World example
A simple "Hello World" example, which results in a file like [01simple.xlsx](Examples_01simple.xlsx):
{{
<?php
/** Error reporting */
error_reporting(E_ALL);

/** Include path **/
ini_set('include_path', ini_get('include_path').';../Classes/');

/** PHPExcel */
include 'PHPExcel.php';

/** PHPExcel_Writer_Excel2007 */
include 'PHPExcel/Writer/Excel2007.php';

// Create new PHPExcel object
echo date('H:i:s') . " Create new PHPExcel object\n";
$objPHPExcel = new PHPExcel();

// Set properties
echo date('H:i:s') . " Set properties\n";
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw");
$objPHPExcel->getProperties()->setLastModifiedBy("Maarten Balliauw");
$objPHPExcel->getProperties()->setTitle("Office 2007 XLSX Test Document");
$objPHPExcel->getProperties()->setSubject("Office 2007 XLSX Test Document");
$objPHPExcel->getProperties()->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.");


// Add some data
echo date('H:i:s') . " Add some data\n";
$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Hello');
$objPHPExcel->getActiveSheet()->SetCellValue('B2', 'world!');
$objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Hello');
$objPHPExcel->getActiveSheet()->SetCellValue('D2', 'world!');

// Rename sheet
echo date('H:i:s') . " Rename sheet\n";
$objPHPExcel->getActiveSheet()->setTitle('Simple');

		
// Save Excel 2007 file
echo date('H:i:s') . " Write to Excel2007 format\n";
$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));

// Echo done
echo date('H:i:s') . " Done writing file.\r\n";
}}