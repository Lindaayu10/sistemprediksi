|| [Home](Home) || **+Features+** || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Documents](Documents) || [Credits](Credits) || [Contact](Contact) ||

# Features
PHPExcel currently features:
* Create an in-memory spreadsheet representation
* Set spreadsheet meta data (author, title, description, ...)
* Add worksheets to spreadsheet
* Add data and formulas to individual cells
* Merge cells
* Protect ranges of cells with a password
* Supports setting cell width and height
* Supports different fonts and font styles
* Supports formatting, styles, cell borders, fills, gradients, ...
* Supports hyperlinks
* Supports different data types for individual cells
* Supports cell text wrapping
* Supports conditional formatting
* Supports column auto-sizing
* Supports rich-text strings
* Supports autofilter
* Supports "freezing" cell panes
* Supports cell-level security
* Supports workbook-level security
* Supports worksheet-level protection
* Group rows/columns
* Cell data validation
* Insert/remove rows/columns
* Named ranges
* Worksheet references
* Calculate formula values
* Add comments to a cell
* Add images to your spreadsheet
* Set image styles
	* Positioning
	* Rotation
	* Shadow
* Set printing options
	* Header
	* Footer
	* Page margins
	* Paper size
	* Orientation
	* Row and column breaks
	* Repeat rows at header / columns at left
	* Print area
* Output your spreadsheet object to different file formats
	* Excel 2007 (spreadsheetML)
	* BIFF8 (Excel 97 and higher)
	* PHPExcel Serialized Spreadsheet
	* CSV (Comma Separated Values)
	* HTML
	* PDF
* Read different file formats into your spreadsheet object
	* Excel 2007 (spreadsheetML)
	* BIFF5 (Excel 5.0 / Excel 95), BIFF8 (Excel 97 and higher)
	* PHPExcel Serialized Spreadsheet
	* Excel 2003 XML format
	* Open Office Calc (.ods)
	* Gnumeric
	* Symbolic Link (SYLK)
	* CSV (Comma Separated Values)
* ... and lots of other things!

An example of what can be currently achieved: (other [Examples](Examples))
![](Features_features.png)