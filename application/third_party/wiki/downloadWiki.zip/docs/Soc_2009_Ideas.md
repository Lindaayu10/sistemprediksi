|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Documents](Documents) || [Credits](Credits) || [Contact](Contact) ||

# Google Summer of Code 2009 - Ideas page

|This page is related to [Google Summer of Code 2009](http://code.google.com/soc/) and contains ideas for SoC students. The items on this page are the ideas that we think would be the best projects for a SoC student and which would provide a lot of value to PHPExcel. Please don't think that this is an exclusive list. If you'ld like to work on something that isn't listed here, please feel free to [submit a proposal](http://phpexcel.codeplex.com/Wiki/View.aspx?title=Contribute&referringTitle=Home). Don't hesitate to ask for details or start discussing one of these tasks on the [discussion board](http://phpexcel.codeplex.com/Thread/List.aspx).|![](Soc_2009_Ideas_2009socwithlogo.gif)|

Make sure you have a look at the PHPExcel documentation (to be found in the latest release: [release:10715](release_10715)), which contains some information on the architecture of PHPExcel.

## Implement ODF 'Calc' file format
We would love to have basic support for ODF 'Calc' file format, the spreadsheet engine file format supported in OpenOffice.org. At first, we would like to be able to write a Calc spreadsheet from PHPExcel. If time permits, a basic reader implementation is also on our wish list.
* [More on ODF...](http://en.wikipedia.org/wiki/OpenDocument)
* [File format documentation](http://www.oasis-open.org/committees/tc_home.php?wg_abbrev=office)

**Work item:** [workitem:1930](workitem_1930) 
**Difficulty:** intermediate

## Implement Gnumeric File Format
We would love to have basic support for the Gnumeric file format ([http://www.gnome.org/gnumeric](http://www.gnome.org/gnumeric)). At first, we would like to be able to write a Gnumeric spreadsheet from PHPExcel. If time permits, a basic reader implementation is also on our wish list.
* [More on Gnumeric...](http://en.wikipedia.org/wiki/Gnumeric)
* [File format documentation](http://projects.gnome.org/gnumeric/doc/file-format-gnumeric.shtml)

**Work item:** [workitem:8769](workitem_8769) 
**Difficulty:** intermediate

## Implement document reflector
In the Office Open XML SDK, there is a tool which can be used to [generate source code from an existing document](http://blogs.msdn.com/dmahugh/archive/2008/09/08/open-xml-sdk-xmlspy-standard-edition-and-custom-markup.aspx). We would love to see this sort of thing supported in PHPExcel. One should be able to load an existing spreadsheet in PHPExcel and save it using the "document reflector" which generates all PHP code that constructs the current PHPExcel object.

**Work item:** [workitem:7550](workitem_7550) 
**Difficulty:** intermediate

## Various work items
In our issue tracker, we have a number of outstanding bugs and feature requests. Feel free to address one (or more) from our [issue tracker](http://phpexcel.codeplex.com/WorkItem/AdvancedList.aspx).

## Own proposals?
The items on this page are the ideas that we think would be the best projects for a SoC student and which would provide a lot of value to PHPExcel. Please don't think that this is an exclusive list. If you'ld like to work on something that isn't listed here, please feel free to [submit a proposal](http://phpexcel.codeplex.com/Wiki/View.aspx?title=Contribute&referringTitle=Home). Don't hesitate to ask for details or start discussing one of these tasks on the [discussion board](http://phpexcel.codeplex.com/Thread/List.aspx).