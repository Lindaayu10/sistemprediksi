|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Documents](Documents) || **+Credits+** || [Contact](Contact) ||

# Credits
## Current team members
* Maarten Balliauw, Project manager / Developer, [http://blog.maartenballiauw.be](http://blog.maartenballiauw.be)
* Mark Baker, Developer
* Erik Tilt, Developer

Check [http://www.codeplex.com/PHPExcel/People/ProjectPeople.aspx](http://www.codeplex.com/PHPExcel/People/ProjectPeople.aspx) for a complete list of current team members.

## Once part of the team...
* [c960657](http://www.codeplex.com/site/users/view/c960657)
* [GarethInWales](http://www.codeplex.com/site/users/view/GarethInWales)
* [Jazzo](http://www.codeplex.com/site/users/view/Jazzo)
* [lexayo](http://www.codeplex.com/site/users/view/lexayo)
* [maecka](http://www.codeplex.com/site/users/view/maecka)
* [mdavis](http://www.codeplex.com/site/users/view/mdavis)
* [pufuwozu](http://www.codeplex.com/site/users/view/pufuwozu)
* [shangxiao](http://www.codeplex.com/site/users/view/shangxiao)
* [sstoiana](http://www.codeplex.com/site/users/view/sstoiana)
* [vrana](http://www.codeplex.com/site/users/view/vrana)
* [whisper](http://www.codeplex.com/site/users/view/whisper)

Check [http://www.codeplex.com/PHPExcel/People/ProjectPeople.aspx](http://www.codeplex.com/PHPExcel/People/ProjectPeople.aspx) for a complete list of current team members.

## PHPExcel team wants to thank...
* Joris Poelmans [http://jopx.blogspot.com](http://jopx.blogspot.com)
* Wouter van Vugt [http://blogs.infosupport.com/wouterv/](http://blogs.infosupport.com/wouterv/)
* Doug Mahugh [http://blogs.msdn.com/dmahugh/](http://blogs.msdn.com/dmahugh/)
* Paul Meagher [http://www.phpmath.com/home](http://www.phpmath.com/home)

## PHPExcel contains portions of code from...
* PEAR::Spreadsheet_Excel_Writer ([http://pear.php.net/package/Spreadsheet_Excel_Writer](http://pear.php.net/package/Spreadsheet_Excel_Writer))
* JavaScript Excel Formula Parser ([http://ewbi.blogs.com/develops/2007/03/excel_formula_p.html](http://ewbi.blogs.com/develops/2007/03/excel_formula_p.html))
* PHP-ExcelReader ([http://sourceforge.net/projects/phpexcelreader](http://sourceforge.net/projects/phpexcelreader))
* FPDF ([http://www.fpdf.org/](http://www.fpdf.org/))
* TCPDF ([http://www.tcpdf.org/](http://www.tcpdf.org/))
* PHP port of polyfit ([http://www.phpmath.com/home?op=cat&cid=17](http://www.phpmath.com/home?op=cat&cid=17))
* PHP port of JAMA matrix library ([http://www.phpmath.com/build03/JAMA/docs/](http://www.phpmath.com/build03/JAMA/docs/))