|| [Home](Home) || [Features](Features) || **+Requirements+** || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Documents](Documents) || [Credits](Credits) || [Contact](Contact) ||

# Requirements
* PHP version 5.2.0 or higher
* PHP extension php_zip enabled *)
* PHP extension php_xml enabled
* PHP extension php_gd2 enabled (if not compiled in)

All part of the PHP package (zip) on http://www.php.net/downloads.php, should be enabled in php.ini

*) {"php_zip"} is only needed by {"PHPExcel_Reader_Excel2007"}, {"PHPExcel_Writer_Excel2007"}, {"PHPExcel_Reader_OOCalc"}. In other words, if you need PHPExcel to handle .xlsx or .ods files you will need the zip extension, but otherwise not.