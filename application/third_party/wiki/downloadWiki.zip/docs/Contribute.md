|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || **+Contribute+** || [Documents](Documents) || [Credits](Credits) || [Contact](Contact) ||

# Contribute to PHPExcel
We switched the PHPExcel source code repository to github in June 2012, and the source tab here on codeplex no longer references current code. If you wish to contribute or provide patches and bugfixes, please fork our github repository (develop branch) and submit pull requests


## Contribute bugs, feature requests, ...
Found a bug? Have a feature request? Please create a work item on [http://www.codeplex.com/PHPExcel/WorkItem/AdvancedList.aspx](http://www.codeplex.com/PHPExcel/WorkItem/AdvancedList.aspx) or on [https://github.com/PHPOffice/PHPExcel/issues?page=1&sort=updated&state=open](https://github.com/PHPOffice/PHPExcel/issues?page=1&sort=updated&state=open).

If you have a small piece of code that can solve a problem / add a new feature, you can also communicate this to us using a work item.

## Have a patch?
Created a patch for a bug or feature? Please submit it as a pull request to[https://github.com/PHPOffice/PHPExcel](https://github.com/PHPOffice/PHPExcel).

## Direct contributions to code
Want to make direct contributions to code? Please read the [PHPExcel project guidelines.doc](Contribute_PHPExcel project guidelines.doc), and contact the project manager (see [Contact](Contact)).